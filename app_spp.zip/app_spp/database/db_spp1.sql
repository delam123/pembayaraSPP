-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 17, 2023 at 03:37 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_spp1`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `cekLoginPetugas` (IN `uname` VARCHAR(100), IN `pass` VARCHAR(100))   BEGIN
	SELECT * FROM petugas WHERE username = uname AND PASSWORD = pass;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `cekLoginSiswa` (IN `nis_` VARCHAR(100), IN `pass` VARCHAR(100))   BEGIN
SELECT * FROM siswa WHERE nis = nis_ AND PASSWORD = pass;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `levelPetugas` (IN `uname` VARCHAR(100), IN `pass` VARCHAR(100))   BEGIN
SELECT * FROM petugas WHERE username = uname AND PASSWORD = pass;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `tampilData` (IN `tabel` VARCHAR(50), IN `kolom` VARCHAR(50))   BEGIN 
DECLARE tab varchar(50);
SET tab = tabel;
SELECT * FROM tab ORDER BY kolom desc;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `kelas`
--

CREATE TABLE `kelas` (
  `id_kelas` int(11) NOT NULL,
  `nama_kelas` enum('10 RPL 1','10 RPL 2','10 RPL 3','10 TKJ 1','10 TKJ 2','10 TKJ 3','10 BDP 1','10 BDP 2','10 BDP 3','10 OTKP 1','10 OTKP 2','10 OTKP 3','10 AKL 1','10 AKL 2','10 AKL 3','10 AKL 4','10 UPW 1','10 UPW 2','11 RPL 1','11 RPL 2','11 RPL 3','11 TKJ 1','11 TKJ 2','11 TKJ 3','11 BDP 1','11 BDP 2','11 BDP 3','11 OTKP 1','11 OTKP 2','11 OTKP 3','11 AKL 1','11 AKL 2','11 AKL 3','11 AKL 4','11 UPW 1','11 UPW 2','12 RPL 1','12 RPL 2','12 RPL 3','12 TKJ 1','12 TKJ 2','12 TKJ 3','12 BDP 1','12 BDP 2','12 BDP 3','12 OTKP 1','12 OTKP 2','12 OTKP 3','12 AKL 1','12 AKL 2','12 AKL 3','12 AKL 4','12 UPW 1','12 UPW 2') NOT NULL,
  `kompetensi_keahlian` enum('Rekayasa Perangkat Lunak','Teknik Komputer dan Jaringan','Otomatisasi Tata Kelola Perkantoran','Akutansi Keuangan Lembaga','Bisnis Daring Pemasaran','Usaha Perjalanan Wisata') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `kelas`
--

INSERT INTO `kelas` (`id_kelas`, `nama_kelas`, `kompetensi_keahlian`) VALUES
(1, '10 RPL 2', 'Rekayasa Perangkat Lunak'),
(2, '11 OTKP 3', 'Otomatisasi Tata Kelola Perkantoran'),
(3, '12 TKJ 2', 'Teknik Komputer dan Jaringan'),
(4, '12 UPW 2', 'Usaha Perjalanan Wisata'),
(5, '11 UPW 1', 'Usaha Perjalanan Wisata'),
(8, '12 RPL 3', 'Rekayasa Perangkat Lunak'),
(9, '12 RPL 3', 'Rekayasa Perangkat Lunak');

-- --------------------------------------------------------

--
-- Table structure for table `pembayaran`
--

CREATE TABLE `pembayaran` (
  `id_pembayaran` int(11) NOT NULL,
  `id_petugas` int(11) NOT NULL,
  `nisn` char(10) NOT NULL,
  `tgl_bayar` date NOT NULL,
  `bulan_dibayar` enum('January','Febuari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember') NOT NULL,
  `tahun_dibayar` year(4) NOT NULL,
  `id_spp` int(11) NOT NULL,
  `jumlah_bayar` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pembayaran`
--

INSERT INTO `pembayaran` (`id_pembayaran`, `id_petugas`, `nisn`, `tgl_bayar`, `bulan_dibayar`, `tahun_dibayar`, `id_spp`, `jumlah_bayar`) VALUES
(1, 1, '001', '2023-02-01', 'Febuari', 2022, 1, 500000),
(4, 1, '001', '2022-03-01', 'Maret', 2023, 1, 600000),
(5, 2, '002', '2021-01-05', 'January', 2022, 3, 500000),
(7, 1, '002', '2023-03-06', 'Maret', 2023, 1, 900000),
(8, 1, '001', '2023-01-06', 'January', 2023, 1, 700000),
(10, 1, '002', '2023-03-07', 'Maret', 2023, 1, 520000),
(15, 1, '003', '2023-03-07', 'Maret', 2023, 1, 800000),
(22, 1, '003', '2022-05-09', 'Mei', 2022, 1, 300000),
(24, 1, '002', '2023-03-09', 'Maret', 2023, 1, 300000),
(25, 1, '003', '2022-08-09', 'Agustus', 2022, 1, 600000),
(26, 1, '002', '2023-03-10', 'Maret', 2023, 1, 270000),
(27, 1, '002', '2023-03-11', 'Maret', 2023, 1, 350000),
(29, 1, '001', '2023-03-12', 'Maret', 2023, 4, 520000),
(30, 2, '002', '2023-03-12', 'Maret', 2023, 1, 300000),
(31, 1, '001', '2023-03-13', 'Maret', 2023, 4, 260000),
(32, 1, '001', '2023-03-13', 'Maret', 2023, 4, 260000),
(33, 1, '001', '2023-03-13', 'Maret', 2023, 4, 260000),
(34, 1, '002', '2023-03-15', 'Maret', 2023, 1, 300000),
(35, 1, '001', '2023-03-15', 'Maret', 2023, 4, 260000),
(36, 1, '003', '2023-03-15', 'Maret', 2023, 6, 450000),
(37, 1, '004', '2023-03-15', 'Maret', 2023, 1, 300000),
(38, 1, '004', '2023-03-15', 'Maret', 2023, 1, 300000),
(39, 1, '002', '2023-03-16', 'Maret', 2023, 5, 500000);

-- --------------------------------------------------------

--
-- Table structure for table `petugas`
--

CREATE TABLE `petugas` (
  `id_petugas` int(11) NOT NULL,
  `username` varchar(25) NOT NULL,
  `password` varchar(32) NOT NULL,
  `nama_petugas` varchar(35) NOT NULL,
  `level` enum('admin','petugas','siswa') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `petugas`
--

INSERT INTO `petugas` (`id_petugas`, `username`, `password`, `nama_petugas`, `level`) VALUES
(1, 'admin', '202cb962ac59075b964b07152d234b70', 'Dela Maelani', 'admin'),
(2, 'petugas', '202cb962ac59075b964b07152d234b70', 'Diki Patria', 'petugas'),
(3, 'syaidatul', '310dcbbf4cce62f762a2aaa148d556bd', 'Syaidatul Musa\'idah', 'petugas'),
(5, 'petugas2', '202cb962ac59075b964b07152d234b70', 'Nina Aprilia', 'petugas'),
(6, 'admin1', 'd81f9c1be2e08964bf9f24b15f0e4900', 'Nina', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `siswa`
--

CREATE TABLE `siswa` (
  `nisn` char(10) NOT NULL,
  `nis` char(12) NOT NULL,
  `nama` varchar(35) NOT NULL,
  `id_kelas` int(11) NOT NULL,
  `password` varchar(255) NOT NULL,
  `alamat` text NOT NULL,
  `no_telp` varchar(13) NOT NULL,
  `id_spp` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `siswa`
--

INSERT INTO `siswa` (`nisn`, `nis`, `nama`, `id_kelas`, `password`, `alamat`, `no_telp`, `id_spp`) VALUES
('001', '202110065041', 'Dela Maelani', 1, '202cb962ac59075b964b07152d234b70', 'Kuningan', '08776546785', 4),
('002', '202110065042', 'Febi Vitaloka', 3, '202cb962ac59075b964b07152d234b70', 'Kuningan', '0888657768', 5),
('003', '202110065043', 'Nancy', 5, '202cb962ac59075b964b07152d234b70', 'Bekasi', '089765434', 6),
('004', '202110065047', 'Romi', 3, '202cb962ac59075b964b07152d234b70', 'Cijoho', '0897654356', 1);

-- --------------------------------------------------------

--
-- Table structure for table `spp`
--

CREATE TABLE `spp` (
  `id_spp` int(11) NOT NULL,
  `tahun` int(11) NOT NULL,
  `nominal` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `spp`
--

INSERT INTO `spp` (`id_spp`, `tahun`, `nominal`) VALUES
(1, 2023, 300000),
(3, 2022, 250000),
(4, 2021, 260000),
(5, 2019, 500000),
(6, 2020, 450000);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `kelas`
--
ALTER TABLE `kelas`
  ADD PRIMARY KEY (`id_kelas`);

--
-- Indexes for table `pembayaran`
--
ALTER TABLE `pembayaran`
  ADD PRIMARY KEY (`id_pembayaran`),
  ADD KEY `id_petugas` (`id_petugas`),
  ADD KEY `nisn` (`nisn`),
  ADD KEY `id_spp` (`id_spp`);

--
-- Indexes for table `petugas`
--
ALTER TABLE `petugas`
  ADD PRIMARY KEY (`id_petugas`);

--
-- Indexes for table `siswa`
--
ALTER TABLE `siswa`
  ADD PRIMARY KEY (`nisn`),
  ADD KEY `id_kelas` (`id_kelas`),
  ADD KEY `id_spp` (`id_spp`);

--
-- Indexes for table `spp`
--
ALTER TABLE `spp`
  ADD PRIMARY KEY (`id_spp`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `kelas`
--
ALTER TABLE `kelas`
  MODIFY `id_kelas` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `pembayaran`
--
ALTER TABLE `pembayaran`
  MODIFY `id_pembayaran` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `petugas`
--
ALTER TABLE `petugas`
  MODIFY `id_petugas` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `spp`
--
ALTER TABLE `spp`
  MODIFY `id_spp` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `pembayaran`
--
ALTER TABLE `pembayaran`
  ADD CONSTRAINT `pembayaran_ibfk_1` FOREIGN KEY (`id_petugas`) REFERENCES `petugas` (`id_petugas`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `pembayaran_ibfk_3` FOREIGN KEY (`id_spp`) REFERENCES `spp` (`id_spp`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `pembayaran_ibfk_4` FOREIGN KEY (`nisn`) REFERENCES `siswa` (`nisn`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `siswa`
--
ALTER TABLE `siswa`
  ADD CONSTRAINT `siswa_ibfk_1` FOREIGN KEY (`id_kelas`) REFERENCES `kelas` (`id_kelas`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `siswa_ibfk_2` FOREIGN KEY (`id_spp`) REFERENCES `spp` (`id_spp`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
